#include <stdio.h>
 
int main() {
 
    float notaA, notaB, Media;
    scanf("%f %f", &notaA, &notaB);
    Media=(notaA*3.5 + notaB*7.5)/11;
    printf("MEDIA = %.5f\n", Media);
 
    return 0;
}